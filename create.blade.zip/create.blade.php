<x-app-layout>

    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Post aanmaken') }}
        </h2>
    </x-slot>

    <div class="max-w-4xl mx-auto bg-white rounded-2xl my-10 p-10">

    <form action="{{ route('posts.store') }}" method="post" enctype="multipart/form-data">
        @csrf

        <div>
            <label for="title" class="block text-sm font-medium leading-6 text-gray-900">Titel</label>
            <div class="relative mt-2 rounded-md shadow-sm">
                <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                    <span class="text-gray-500 sm:text-sm"></span>
                </div>
                <input type="text" name="title" id="price" class="block w-5/6 rounded-md border-0 py-1.5 pl-7 pr-20 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">

            </div>
        </div>

        <br>


        @error('title')
    {{$message}}
        @enderror

        <textarea name="body" id="" cols="84" rows="5"></textarea>

        @error('body')
        {{$message}}
        @enderror
        <input type="file" name="image">

        @error('image')
        {{$message}}
        @enderror
        <br>
        <br>

        <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full">aanmaken</button>
    </form>

    </div>

</x-app-layout>
