<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Posts overzicht') }}
        </h2>
    </x-slot>

    @if(session('success'))
        {{ session('success') }}<br><br>
    @endif

    <div class="max-w-4xl mx-auto bg-white rounded-2xl my-10 p-10">
        <a href="{{ route('posts.create') }}">
            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-full">
                Aanmaken
            </button>
        </a>
        <br>
        <br>
        <br>
        <div class="grid grid-cols-2 gap-4 mx-auto">
            @foreach($posts as $post)

                <div class="border rounded-xl">
                    <img class="w-5/6" src="{{ asset('storage/' . $post->image) }}" alt="">
                    <div class="flex mt-2 justify-center">
                        {{ $post->title }} <br>
                        {{ $post->body }}
                    </div>
                    <div class="flex mt-2 justify-center gap-4">
                        <a class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-1 px-1 rounded-full"
                           href="{{ route('posts.edit', $post->id) }}">Bewerken</a>
                        <form action="{{ route('posts.destroy', $post->id) }}" method="post">
                            @csrf
                            @method('delete')
                            <button class="bg-red-500 hover:bg-blue-700 text-white font-bold py-1 px-1 rounded-full">
                                verwijderen
                            </button>
                        </form>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-app-layout>
