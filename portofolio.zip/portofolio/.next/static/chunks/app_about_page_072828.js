(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_about_page_072828.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_about_page_072828.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_b075cf._.js",
    "static/chunks/d9ef2_@firebase_auth_dist_esm2017_eadad8._.js",
    "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa.js",
    "static/chunks/node_modules_f7aca9._.js",
    "static/chunks/_118091._.js"
  ],
  "source": "dynamic"
});
