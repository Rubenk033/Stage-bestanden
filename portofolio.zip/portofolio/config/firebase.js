import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyCGY8CfWeUf5mjo9ky3Dh0mJi6KuOMTkJ4",
    authDomain: "portofolio-485d6.firebaseapp.com",
    projectId: "portofolio-485d6",
    storageBucket: "portofolio-485d6.appspot.com",
    messagingSenderId: "590907655595",
    appId: "1:590907655595:web:22a5ff847ba82060be3eee"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
