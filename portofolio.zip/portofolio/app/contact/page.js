"use client";

import { useState, useEffect } from "react";
import {
    GoogleAuthProvider,
    signInWithPopup,
    onAuthStateChanged,
    signOut,
    setPersistence,
    browserLocalPersistence,
} from "firebase/auth";
import { auth, db } from "@/config/firebase.js";
import { collection, getDocs, addDoc } from "firebase/firestore";
import Link from "next/link";

export default function ContactPage() {
    const provider = new GoogleAuthProvider();
    const adminEmail = "flint.bruinekool@gmail.com";

    const [user, setUser] = useState(null);
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState("");
    const [messages, setMessages] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            if (user) {
                if (user.email === adminEmail) {
                    setUser(user);
                    fetchMessages();
                } else {
                    signOut(auth)
                        .then(() => {
                            setUser(null);
                        })
                        .catch((error) => console.error("Fout bij uitloggen:", error));
                }

            } else {
                setUser(null);
            }
        });

        return () => unsubscribe();
    }, []);

    const fetchMessages = async () => {
        try {
            setLoading(true);
            const querySnapshot = await getDocs(collection(db, "contact_messages"));
            const fetchedMessages = querySnapshot.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));
            setMessages(fetchedMessages);
        } catch (err) {
            console.error("Fout bij het ophalen van berichten:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!name || !email || !message) {
            setError("Alle velden zijn verplicht.");
            return;
        }

        try {
            await addDoc(collection(db, "contact_messages"), {
                name,
                email,
                message,
                timestamp: new Date(),
            });
            setError("");
            setSuccess(true);
            setName("");
            setEmail("");
            setMessage("");
        } catch (err) {
            console.error("Fout bij het verzenden:", err);
            setError("Er is een fout opgetreden bij het verzenden. Probeer het later opnieuw.");
        }
    };

    const firebaseSignIn = () => {
        setPersistence(auth, browserLocalPersistence)
            .then(() => signInWithPopup(auth, provider))
            .catch((error) => console.error("Fout bij inloggen:", error));
    };

    const handleLogout = () => {
        signOut(auth)
            .then(() => {
                setUser(null);
            })
            .catch((error) => console.error("Fout bij uitloggen:", error));
    };

    return (
        <div className="relative min-h-screen w-full">
            <header className="w-full bg-gray-800 text-white px-6 py-4 flex justify-between items-center">
                <h1 className="text-2xl font-bold">Mijn Portfolio</h1>
                <nav className="space-x-6">
                    <Link href="/" className="hover:underline">Home</Link>
                    <Link href="/projects" className="hover:underline">Projecten</Link>
                    <Link href="/contact" className="hover:underline">Contact</Link>
                </nav>
                <div>
                    {!user ? (
                        <button
                            onClick={firebaseSignIn}
                            className="bg-blue-500 text-white px-3 py-1 rounded-lg hover:bg-blue-600"
                        >
                            Log in met Google
                        </button>
                    ) : (
                        <div className="flex items-center space-x-4">
                            <button
                                onClick={handleLogout}
                                className="bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600"
                            >
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            </header>
            <main className="flex flex-col items-center py-10 px-4">
                <h1 className="text-4xl font-bold mb-6">Neem contact op</h1>

                <form
                    onSubmit={handleSubmit}
                    className="w-full max-w-md bg-white shadow-md rounded-lg p-6 mb-10"
                >
                    {error && <p className="text-red-500 mb-4">{error}</p>}
                    {success && <p className="text-green-500 mb-4">Bericht verzonden!</p>}

                    <div className="mb-4">
                        <label htmlFor="name" className="block font-medium mb-2">Naam</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg"
                            placeholder="Jouw naam"
                        />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="email" className="block font-medium mb-2">E-mailadres</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg"
                            placeholder="Jouw e-mailadres"
                        />
                    </div>

                    <div className="mb-4">
                        <label htmlFor="message" className="block font-medium mb-2">Bericht</label>
                        <textarea
                            id="message"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            rows="3"
                            className="w-full px-3 py-2 border rounded-lg"
                            placeholder="Jouw bericht"
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600"
                    >
                        Verzenden
                    </button>
                </form>

                {user?.email === adminEmail && (
                    <div className="w-full max-w-4xl bg-gray-100 p-6 rounded-lg shadow-md">
                        <h2 className="text-2xl font-bold mb-4">Verstuurde berichten</h2>
                        {loading ? (
                            <p>Berichten laden...</p>
                        ) : messages.length > 0 ? (
                            <table className="w-full table-auto">
                                <thead>
                                <tr className="bg-gray-300">
                                    <th className="px-4 py-2">Naam</th>
                                    <th className="px-4 py-2">E-mail</th>
                                    <th className="px-4 py-2">Bericht</th>
                                    <th className="px-4 py-2">Tijd</th>
                                </tr>
                                </thead>
                                <tbody>
                                {messages.map((msg) => (
                                    <tr key={msg.id} className="border-t">
                                        <td className="px-4 py-2">{msg.name}</td>
                                        <td className="px-4 py-2">{msg.email}</td>
                                        <td className="px-4 py-2">{msg.message}</td>
                                        <td className="px-4 py-2">
                                            {new Date(msg.timestamp?.seconds * 1000).toLocaleString()}
                                        </td>
                                    </tr>
                                ))}
                                </tbody>
                            </table>
                        ) : (
                            <p>Geen berichten gevonden.</p>
                        )}
                    </div>
                )}
            </main>

            {/* Footer */}
            <footer className="bg-gray-800 text-white py-4 px-6">
                <div className="flex justify-between items-center max-w-5xl mx-auto">
                    <p>&copy; 2025 Flint Bruinekool</p>
                    <div className="space-x-4">
                        <a
                            href="https://github.com/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            GitHub
                        </a>
                        <a
                            href="https://linkedin.com/in/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            LinkedIn
                        </a>
                        <a
                            href="mailto:flint.bruinekool@gmail.com"
                            className="hover:underline"
                        >
                            Contact
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    );
}
