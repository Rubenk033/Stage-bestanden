"use client";

import { useState, useEffect } from "react";
import {
    GoogleAuthProvider,
    signInWithPopup,
    onAuthStateChanged,
    signOut,
} from "firebase/auth";
import { db } from "@/config/firebase.js";
import {
    collection,
    getDocs,
    addDoc,
    deleteDoc,
    updateDoc,
    doc,
} from "firebase/firestore";
import Link from "next/link";
import { auth } from "@/config/firebase";

export default function ProjectsPage() {
    const provider = new GoogleAuthProvider();
    const adminEmail = "flint.bruinekool@gmail.com";
    const [user, setUser] = useState(null);
    const [projects, setProjects] = useState([]);
    const [newProject, setNewProject] = useState({ title: "", description: "", imageUrl: "", language: "" });
    const [updatedProject, setUpdatedProject] = useState({ title: "", description: "", imageUrl: "", language: "" });
    const [editingProject, setEditingProject] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [modalImage, setModalImage] = useState(null);
    const [filter, setFilter] = useState("Alles");
    const languages = ["Alles", "HTML/CSS", "PHP", "JavaScript", "NextJS", "LuaLove", "Laravel" ];

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
            setUser(currentUser);
            await fetchProjects();
        });

        return () => unsubscribe();
    }, []);

    const fetchProjects = async () => {
        try {
            setLoading(true);
            const querySnapshot = await getDocs(collection(db, "projects"));
            const fetchedProjects = querySnapshot.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));
            setProjects(fetchedProjects);
        } catch (err) {
            console.error("Error fetching projects:", err);
        } finally {
            setLoading(false);
        }
    };

    const handleAddProject = async (e) => {
        e.preventDefault();
        if (!newProject.title || !newProject.description || !newProject.imageUrl || !newProject.language) {
            setError("All fields are required.");
            return;
        }

        try {
            await addDoc(collection(db, "projects"), {
                ...newProject,
                timestamp: new Date(),
            });
            setNewProject({ title: "", description: "", imageUrl: "", language: "" });
            setError("");
            await fetchProjects();
        } catch (err) {
            console.error("Error adding project:", err);
            setError("Failed to add project.");
        }
    };

    const handleDeleteProject = async (id) => {
        try {
            await deleteDoc(doc(db, "projects", id));
            await fetchProjects();
        } catch (err) {
            console.error("Error deleting project:", err);
        }
    };

    const handleEditProject = (project) => {
        setEditingProject(project);
        setUpdatedProject({
            title: project.title,
            description: project.description,
            imageUrl: project.imageUrl,
            language: project.language,
        });
    };

    const handleUpdateProject = async (e) => {
        e.preventDefault();
        if (!updatedProject.title || !updatedProject.description || !updatedProject.imageUrl || !updatedProject.language) {
            setError("Vul al de velden in.");
            return;
        }

        try {
            const projectRef = doc(db, "projects", editingProject.id);
            await updateDoc(projectRef, {
                ...updatedProject,
                timestamp: new Date(),
            });
            setEditingProject(null);
            setUpdatedProject({ title: "", description: "", imageUrl: "", language: "" });
            setError("");
            await fetchProjects();
        } catch (err) {
            console.error("Error updating project:", err);
            setError("Failed to update project.");
        }
    };

    const openModal = (imageUrl) => setModalImage(imageUrl);
    const closeModal = () => setModalImage(null);

    const filteredProjects = projects.filter((project) =>
        filter === "Alles" ? true : project.language === filter
    );

    return (
        <div className="relative min-h-screen w-full">
            <header className="w-full bg-gray-800 text-white px-6 py-4 flex justify-between items-center">
                <h1 className="text-2xl font-bold">Mijn Portfolio</h1>
                <nav className="space-x-6">
                    <Link href="/" className="hover:underline">Home</Link>
                    <Link href="/projects" className="hover:underline">Projecten</Link>
                    <Link href="/contact" className="hover:underline">Contact</Link>
                </nav>
                <div>
                    {!user ? (
                        <button
                            onClick={() => signInWithPopup(auth, provider)}
                            className="bg-blue-500 text-white px-3 py-1 rounded-lg hover:bg-blue-600"
                        >
                            Log in met Google
                        </button>
                    ) : (
                        <div className="flex items-center space-x-4">
                            <button
                                onClick={() => signOut(auth)}
                                className="bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600"
                            >
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            </header>

            <main className="flex flex-col items-center py-10 px-4">
                <h1 className="text-4xl font-bold mb-6">Mijn Projecten</h1>

                <div className="mb-6">
                    <label htmlFor="filter" className="block font-medium mb-2">Filter op Programmeertaal</label>
                    <select
                        id="filter"
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="px-3 py-2 border rounded-lg"
                    >
                        {languages.map((language) => (
                            <option key={language} value={language}>
                                {language}
                            </option>
                        ))}
                    </select>
                </div>

                {loading ? (
                    <p>Loading projects...</p>
                ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-6xl">
                        {filteredProjects.map((project) => (
                            <div key={project.id} className="bg-white shadow-md rounded-lg p-4 relative">
                                <h2 className="text-xl font-bold mb-2">{project.title}</h2>
                                <p className="text-gray-700 mb-4">{project.description}</p>
                                <p className="text-sm text-gray-500 italic">Taal: {project.language}</p>
                                {project.imageUrl && (
                                    <img
                                        src={project.imageUrl}
                                        alt={project.title}
                                        className="w-full h-40 object-cover rounded-lg cursor-pointer"
                                        onClick={() => openModal(project.imageUrl)}
                                    />
                                )}
                                {user?.email === adminEmail && (
                                    <div className="absolute top-2 right-2 space-x-2">
                                        <button
                                            onClick={() => handleEditProject(project)}
                                            className="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600"
                                        >
                                            Bewerken
                                        </button>
                                        <button
                                            onClick={() => handleDeleteProject(project.id)}
                                            className="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600"
                                        >
                                            Verwijderen
                                        </button>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}

                {modalImage && (
                    <div
                        className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center"
                        onClick={closeModal}
                    >
                        <img
                            src={modalImage}
                            alt="Vergrote afbeelding"
                            className="max-w-full max-h-full"
                        />
                    </div>
                )}

                {user?.email === adminEmail && !editingProject && (
                    <form
                        onSubmit={handleAddProject}
                        className="w-full max-w-md mt-10 bg-gray-100 p-6 rounded-lg shadow-md"
                    >
                        <h2 className="text-2xl font-bold mb-4">Voeg een nieuw project toe</h2>
                        {error && <p className="text-red-500 mb-4">{error}</p>}
                        <div className="mb-4">
                            <label htmlFor="title" className="block font-medium mb-2">Titel</label>
                            <input
                                type="text"
                                id="title"
                                value={newProject.title}
                                onChange={(e) =>
                                    setNewProject({...newProject, title: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="Projecttitel"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="description" className="block font-medium mb-2">
                                Beschrijving
                            </label>
                            <textarea
                                id="description"
                                value={newProject.description}
                                onChange={(e) =>
                                    setNewProject({...newProject, description: e.target.value})
                                }
                                rows="3"
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="Projectbeschrijving"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="imageUrl" className="block font-medium mb-2">Afbeelding URL</label>
                            <input
                                type="url"
                                id="imageUrl"
                                value={newProject.imageUrl}
                                onChange={(e) =>
                                    setNewProject({...newProject, imageUrl: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="URL naar de afbeelding"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="language" className="block font-medium mb-2">Programmeertaal</label>
                            <select
                                id="language"
                                value={newProject.language}
                                onChange={(e) =>
                                    setNewProject({...newProject, language: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                            >
                                <option value="" disabled>Selecteer een taal</option>
                                {languages.slice(1).map((language) => (
                                    <option key={language} value={language}>
                                        {language}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <button
                            type="submit"
                            className="w-full bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600"
                        >
                            Project Toevoegen
                        </button>
                    </form>
                )}

                {editingProject && (
                    <form
                        onSubmit={handleUpdateProject}
                        className="w-full max-w-md mt-10 bg-gray-100 p-6 rounded-lg shadow-md"
                    >
                        <h2 className="text-2xl font-bold mb-4">Bewerk Project</h2>
                        {error && <p className="text-red-500 mb-4">{error}</p>}
                        <div className="mb-4">
                            <label htmlFor="title" className="block font-medium mb-2">Titel</label>
                            <input
                                type="text"
                                id="title"
                                value={updatedProject.title}
                                onChange={(e) =>
                                    setUpdatedProject({...updatedProject, title: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="Projecttitel"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="description" className="block font-medium mb-2">Beschrijving</label>
                            <textarea
                                id="description"
                                value={updatedProject.description}
                                onChange={(e) =>
                                    setUpdatedProject({...updatedProject, description: e.target.value})
                                }
                                rows="3"
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="Projectbeschrijving"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="imageUrl" className="block font-medium mb-2">Afbeelding URL</label>
                            <input
                                type="url"
                                id="imageUrl"
                                value={updatedProject.imageUrl}
                                onChange={(e) =>
                                    setUpdatedProject({...updatedProject, imageUrl: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                                placeholder="URL naar de afbeelding"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="language" className="block font-medium mb-2">Programmeertaal</label>
                            <select
                                id="language"
                                value={updatedProject.language}
                                onChange={(e) =>
                                    setUpdatedProject({...updatedProject, language: e.target.value})
                                }
                                className="w-full px-3 py-2 border rounded-lg"
                            >
                                <option value="" disabled>Selecteer een taal</option>
                                {languages.slice(1).map((language) => (
                                    <option key={language} value={language}>
                                        {language}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className="flex justify-between">
                            <button
                                type="submit"
                                className="bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600"
                            >
                                Opslaan
                            </button>
                            <button
                                type="button"
                                onClick={() => setEditingProject(null)}
                                className="bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600"
                            >
                                Annuleren
                            </button>
                        </div>
                    </form>
                )}
            </main>

            <footer className="bg-gray-800 text-white py-4 px-6">
                <div className="flex justify-between items-center max-w-5xl mx-auto">
                    <p>&copy; 2025 Flint Bruinekool</p>

                    <div className="space-x-4">
                        <a
                            href="https://github.com/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            GitHub
                        </a>
                        <a
                            href="https://linkedin.com/in/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            LinkedIn
                        </a>
                        <a
                            href="mailto:flint.bruinekool@gmail.com"
                            className="hover:underline"
                        >
                            Contact
                        </a>
                    </div>
                </div>
            </footer>

        </div>
    );
}
