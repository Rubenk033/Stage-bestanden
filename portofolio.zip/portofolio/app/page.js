"use client";

import { useState, useEffect } from "react";
import {
    GoogleAuthProvider,
    signInWithPopup,
    onAuthStateChanged,
    signOut,
    setPersistence,
    browserLocalPersistence,
} from "firebase/auth";
import { auth } from "@/config/firebase.js";
import Link from "next/link";

export default function Home() {
    const provider = new GoogleAuthProvider();
    const [user, setUser] = useState(null);

    const adminEmail = "flint.bruinekool@gmail.com";

    useEffect(() => {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                if (user.email !== adminEmail) {
                    signOut(auth)
                        .then(() => {
                            setUser(null);
                        })
                        .catch((error) => {
                            console.error("Fout bij uitloggen:", error);
                        });
                } else {
                    setUser(user);
                }
            } else {
                setUser(null);
            }
        });
    }, []);
    const firebaseSignIn = () => {
        setPersistence(auth, browserLocalPersistence)
            .then(() => {
                signInWithPopup(auth, provider)
                    .then((result) => {
                        const loggedInUser = result.user;
                        if (loggedInUser.email !== adminEmail) {
                            signOut(auth)
                                .then(() => {
                                    setUser(null);
                                    alert("Je hebt geen toegangsrechten.");
                                })
                                .catch((error) => {
                                    console.error("Fout bij uitloggen:", error);
                                });
                        } else {
                            setUser(loggedInUser);
                        }
                    })
                    .catch((error) => {
                        console.error("Fout bij inloggen:", error);
                    });
            })
            .catch((error) => {
                console.error("Fout bij het instellen van persistentie:", error);
            });
    };

    const handleLogout = () => {
        signOut(auth)
            .then(() => {
                setUser(null);
            })
            .catch((error) => {
                console.error("Fout bij uitloggen:", error);
            });
    };

    return (
        <div className="relative min-h-screen w-full flex flex-col">
            <header className="w-full bg-gray-800 text-white px-6 py-4 flex justify-between items-center">
                <h1 className="text-2xl font-bold">Mijn Portfolio</h1>
                <nav className="space-x-6">
                    <Link href="/" className="hover:underline">
                        Home
                    </Link>
                    <Link href="/projects" className="hover:underline">
                        Projecten
                    </Link>
                    <Link href="/contact" className="hover:underline">
                        Contact
                    </Link>
                </nav>
                <div>
                    {!user ? (
                        <button
                            onClick={firebaseSignIn}
                            className="bg-blue-500 text-white px-3 py-1 rounded-lg hover:bg-blue-600"
                        >
                            Log in met Google
                        </button>
                    ) : (
                        <button
                            onClick={handleLogout}
                            className="bg-red-500 text-white px-3 py-1 rounded-lg hover:bg-red-600"
                        >
                            Logout
                        </button>
                    )}
                </div>
            </header>

            <main className="flex flex-col items-center py-10 px-4 flex-grow">
                {user?.email === adminEmail && (
                    <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 w-full max-w-3xl">
                        <p className="font-bold">Beheerdersmodus</p>
                        <p>Je bent nu ingelogd als admin. Je kunt berichten bekijken en bewerken.</p>
                    </div>
                )}

                <h1 className="text-4xl font-bold mb-6">Welkom op mijn portfolio!</h1>
                <p className="text-lg text-gray-700 mb-10">
                    Bekijk mijn projecten, lees meer over mij, of neem contact met me op.
                </p>

                <div className="max-w-3xl bg-white p-6 rounded-lg shadow-md">
                    <section className="mb-6">
                        <h2 className="text-2xl font-bold mb-4">Wie ben ik?</h2>
                        <p className="text-gray-700 leading-relaxed">
                            Hallo! Mijn naam is Flint Bruinekool, en ik ben een gepassioneerde ontwikkelaar met een
                            liefde voor het bouwen van innovatieve en functionele toepassingen.
                            Ik ben altijd nieuwsgierig naar nieuwe technologieën en zoek graag naar manieren om problemen
                            op te lossen met creatieve oplossingen.
                        </p>
                    </section>

                    <section className="mb-6">
                        <h2 className="text-2xl font-bold mb-4">Mijn Vaardigheden</h2>
                        <ul className="list-disc pl-5 text-gray-700 leading-relaxed">
                            <li>Front-end ontwikkeling: HTML, CSS, PHP, JavaScript, NextJS, Laravel, LuaLove </li>
                            <li>Back-end ontwikkeling: Firebase</li>
                            <li>Databasebeheer: Firestore</li>
                            <li>Git en versiebeheer</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-2xl font-bold mb-4">Waarom ik dit doe</h2>
                        <p className="text-gray-700 leading-relaxed">
                            Voor mij is coderen meer dan alleen werk – het is een passie. Ik geniet ervan om ideeën tot
                            leven te brengen en software te bouwen die waarde toevoegt aan mensen en bedrijven.
                            Of het nu een persoonlijk project is of een samenwerking met een team, ik ben altijd op zoek
                            naar manieren om te leren en te groeien als ontwikkelaar.
                        </p>
                    </section>
                </div>
            </main>
            <footer className="bg-gray-800 text-white py-4 px-6">
                <div className="flex justify-between items-center max-w-5xl mx-auto">
                    <p>&copy; 2025 Flint Bruinekool</p>
                    <div className="space-x-4">
                        <a
                            href="https://github.com/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            GitHub
                        </a>
                        <a
                            href="https://linkedin.com/in/flintbruinekool"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline"
                        >
                            LinkedIn
                        </a>
                        <a
                            href="mailto:flint.bruinekool@gmail.com"
                            className="hover:underline"
                        >
                            Contact
                        </a>
                    </div>
                </div>
            </footer>
        </div>
    );
}
