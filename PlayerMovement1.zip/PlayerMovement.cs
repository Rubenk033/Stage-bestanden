using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;
    public float jumpForce = 3f;
    public Transform groundCheck;
    public LayerMask groundLayer;

    [Header("Dash")]
    public float dashSpeed = 5f;
    public float dashDuration = 0.2f;
    public float dashCooldown = 1f;

    [Header("Shooting")]
    public GameObject projectilePrefab;
    public float projectileSpeed = 10f;

    private Rigidbody2D rb;
    private Animator anim;

    private bool isGrounded;
    private bool isDashing = false;
    private float dashTime;
    private float lastDashTime;
    private int dashDirection;
    private float moveInput;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        // Ground check
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.3f, groundLayer);
        anim.SetBool("isGrounded", isGrounded);
        anim.SetBool("isJumping", !isGrounded);

        if (!isDashing)
        {
            // Bewegen
            moveInput = Input.GetAxisRaw("Horizontal");
            rb.linearVelocity = new Vector2(moveInput * moveSpeed, rb.linearVelocity.y);
            anim.SetBool("isRunning", moveInput != 0f);

            // Flip
            if (moveInput != 0f)
            {
                transform.localScale = new Vector3(Mathf.Sign(moveInput) * Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
            }

            // Jump
            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
                Debug.Log("Jump triggered!");
            }

            // Dash
            if (Input.GetKeyDown(KeyCode.Q) && Time.time >= lastDashTime + dashCooldown)
            {
                dashDirection = (int)Mathf.Sign(moveInput != 0 ? moveInput : transform.localScale.x);
                StartDash();
            }

            // Shoot
            if (Input.GetMouseButtonDown(0))
            {
                Shoot();
            }
        }
        else
        {
            rb.linearVelocity = new Vector2(dashDirection * dashSpeed, 0f);
            if (Time.time >= dashTime)
                EndDash();
        }

        anim.SetBool("isDashing", isDashing);
    }

    void StartDash()
    {
        isDashing = true;
        dashTime = Time.time + dashDuration;
        lastDashTime = Time.time;
        anim.SetTrigger("dash");
    }

    void EndDash()
    {
        isDashing = false;
    }

    void Shoot()
    {
        Debug.Log("Shoot triggered!");
        anim.SetTrigger("shoot");

        GameObject projectile = Instantiate(projectilePrefab, transform.position, Quaternion.identity);

        // Zorg dat het altijd naar rechts schiet t.o.v. facing
        float direction = transform.localScale.x > 0 ? 1f : -1f;
        Rigidbody2D prb = projectile.GetComponent<Rigidbody2D>();
        prb.linearVelocity = new Vector2(direction * projectileSpeed, 0f);

        // Z-index fix (zichtbaar in 2D)
        projectile.transform.position = new Vector3(projectile.transform.position.x, projectile.transform.position.y, 0f);

        // Ignore speler-collision
        Collider2D playerCol = GetComponent<Collider2D>();
        Collider2D projCol = projectile.GetComponent<Collider2D>();
        if (playerCol != null && projCol != null)
        {
            Physics2D.IgnoreCollision(playerCol, projCol);
        }

        // Verwijder na 3 sec
        Destroy(projectile, 3f);
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(groundCheck.position, 0.2f);
    }
}